
// Initialize the map
const map = L.map('map').setView([12.9716, 77.5946], 13); // Centering on Bangalore

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://osm.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Custom battery icon for EV charging stations
const batteryIcon = L.icon({
    iconUrl: 'Battery-icon-design-on-transparent-background-PNG.png', // Path to battery icon
    iconSize: [32, 32], // Size of the icon
    iconAnchor: [16, 32], // Anchor point of the icon
    popupAnchor: [0, -32] // Popup anchor point
});

function updateMapData() {
    // Fetch local data and update map
    fetch('stations.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Clear existing markers
            map.eachLayer((layer) => {
                if (layer instanceof L.Marker) {
                    map.removeLayer(layer);
                }
            });

            // Add new markers with custom battery icon and retain station details
            const stationsInBangalore = [];
            const graph = new Map();

            data.stations.forEach(station => {
                if (station.city === 'Bangalore') {
                    stationsInBangalore.push(station);
                    L.marker([station.latitude, station.longitude], { icon: batteryIcon }).addTo(map)
                        .bindPopup(`${station.name}<br>Ports available: ${station.ports_available}<br>Destination`);
                    
                    // Add station as a node in the graph
                    graph.set(station.name, []);
                }
            });

            // Add edges between stations
            for (let i = 0; i < stationsInBangalore.length; i++) {
                for (let j = i + 1; j < stationsInBangalore.length; j++) {
                    const stationA = stationsInBangalore[i];
                    const stationB = stationsInBangalore[j];
                    const distance = Math.sqrt(
                        Math.pow(stationA.latitude - stationB.latitude, 2) + Math.pow(stationA.longitude - stationB.longitude, 2)
                    );
                    graph.get(stationA.name).push({ node: stationB.name, weight: distance });
                    graph.get(stationB.name).push({ node: stationA.name, weight: distance });
                }
            }

            // Call function to find and route to the nearest charging station
            compareAlgorithms(graph, stationsInBangalore);
        })
        .catch(error => console.error('Error fetching data:', error));
}

// Initial call to fetch and display data
updateMapData();


function addUserLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            const userLat = position.coords.latitude;
            const userLng = position.coords.longitude;
            // Using default anchor icon for user location
            L.marker([userLat, userLng]).addTo(map)
                .bindPopup('You are here')
                .openPopup();
            map.setView([userLat, userLng], 12); // Zoom in on user location
            
            // Update infoBox with user location
            updateInfoBox(userLat, userLng);
        }, (error) => {
            console.error('Error getting user location:', error);
        });
    } else {
        console.error('Geolocation is not supported by this browser.');
    }
}

// Call the function to add user location
addUserLocation();

// Priority queue implementation
class PriorityQueue {
    constructor(compare) {
        this.items = [];
        this.compare = compare;
    }

    enqueue(element) {
        this.items.push(element);
        this.items.sort(this.compare);
    }

    dequeue() {
        return this.items.shift();
    }

    isEmpty() {
        return this.items.length === 0;
    }
}

// Bellman-Ford Algorithm
function bellmanFord(graph, startNode) {
    const distances = {};
    const predecessors = {};

    graph.forEach((_, node) => {
        distances[node] = Infinity;
        predecessors[node] = null;
    });

    distances[startNode] = 0;

    for (let i = 0; i < graph.size - 1; i++) {
        graph.forEach((edges, node) => {
            edges.forEach(edge => {
                const { node: neighbor, weight } = edge;
                const newDist = distances[node] + weight;
                if (newDist < distances[neighbor]) {
                    distances[neighbor] = newDist;
                    predecessors[neighbor] = node;
                }
            });
        });
    }

    // Check for negative weight cycles
    graph.forEach((edges, node) => {
        edges.forEach(edge => {
            const { node: neighbor, weight } = edge;
            if (distances[node] + weight < distances[neighbor]) {
                throw new Error("Graph contains a negative weight cycle");
            }
        });
    });

    return { distances, predecessors };
}

// Floyd-Warshall Algorithm
function floydWarshall(graph) {
    const nodes = Array.from(graph.keys());
    const distances = {};
    const next = {};

    nodes.forEach(u => {
        distances[u] = {};
        next[u] = {};
        nodes.forEach(v => {
            if (u === v) {
                distances[u][v] = 0;
            } else if (graph.get(u).some(e => e.node === v)) {
                const edge = graph.get(u).find(e => e.node === v);
                distances[u][v] = edge.weight;
            } else {
                distances[u][v] = Infinity;
            }
            next[u][v] = v;
        });
    });

    nodes.forEach(k => {
        nodes.forEach(i => {
            nodes.forEach(j => {
                if (distances[i][j] > distances[i][k] + distances[k][j]) {
                    distances[i][j] = distances[i][k] + distances[k][j];
                    next[i][j] = next[i][k];
                }
            });
        });
    });

    return { distances, next };
}

// Dijkstra's algorithm
function dijkstra(graph, startNode) {
    const distances = {};
    const visited = new Set();
    const pq = new PriorityQueue((a, b) => a.priority - b.priority);

    graph.forEach((_, node) => {
        distances[node] = Infinity;
    });

    distances[startNode] = 0;
    pq.enqueue({ node: startNode, priority: 0 });

    while (!pq.isEmpty()) {
        const { node: currentNode } = pq.dequeue();
        visited.add(currentNode);

        graph.get(currentNode).forEach(({ node: neighbor, weight }) => {
            if (!visited.has(neighbor)) {
                const newDist = distances[currentNode] + weight;
                if (newDist < distances[neighbor]) {
                    distances[neighbor] = newDist;
                    pq.enqueue({ node: neighbor, priority: newDist });
                }
            }
        });
    }

    return distances;
}

// Johnson's algorithm
function johnsonsAlgorithm(graph) {
    const augmentedGraph = new Map(graph);

    augmentedGraph.set('s', []);
    graph.forEach((_, node) => {
        augmentedGraph.get('s').push({ node, weight: 0 });
    });

    const { distances: h } = bellmanFord(augmentedGraph, 's');

    if (!h) {
        throw new Error("Graph contains a negative weight cycle");
    }

    const reweightedGraph = new Map();
    graph.forEach((edges, u) => {
        reweightedGraph.set(u, edges.map(({ node: v, weight }) => ({
            node: v,
            weight: weight + h[u] - h[v]
        })));
    });

    const distances = {};
    graph.forEach((_, u) => {
        distances[u] = dijkstra(reweightedGraph, u);
        for (const v in distances[u]) {
            distances[u][v] += h[v] - h[u];
        }
    });

    return distances;
}

//Yen's K-Shortest Path Algorithm
function yenKShortestPaths(graph, startNode, endNode, K) {
    const paths = [];
    const potentialPaths = new PriorityQueue((a, b) => a.priority - b.priority);

    const dijkstraShortestPath = (graph, startNode, endNode) => {
        const distances = {};
        const predecessors = {};
        const pq = new PriorityQueue((a, b) => a.priority - b.priority);
        
        graph.forEach((_, node) => {
            distances[node] = Infinity;
            predecessors[node] = null;
        });

        distances[startNode] = 0;
        pq.enqueue({ node: startNode, priority: 0 });

        while (!pq.isEmpty()) {
            const { node: currentNode } = pq.dequeue();

            if (currentNode === endNode) {
                const path = [];
                let step = endNode;
                while (step) {
                    path.unshift(step);
                    step = predecessors[step];
                }
                return { path, cost: distances[endNode] };
            }

            graph.get(currentNode).forEach(({ node: neighbor, weight }) => {
                const newDist = distances[currentNode] + weight;
                if (newDist < distances[neighbor]) {
                    distances[neighbor] = newDist;
                    predecessors[neighbor] = currentNode;
                    pq.enqueue({ node: neighbor, priority: newDist });
                }
            });
        }

        return null;
    };

    const shortestPath = dijkstraShortestPath(graph, startNode, endNode);
    if (shortestPath) {
        paths.push(shortestPath);
        for (let k = 1; k < K; k++) {
            const lastPath = paths[paths.length - 1].path;
            for (let i = 0; i < lastPath.length - 1; i++) {
                const spurNode = lastPath[i];
                const rootPath = lastPath.slice(0, i + 1);
                
                const modifiedGraph = new Map(graph);
                modifiedGraph.forEach((edges, node) => {
                    edges = edges.filter(({ node }) => !rootPath.includes(node));
                    modifiedGraph.set(node, edges);
                });

                rootPath.slice(0, -1).forEach((node) => {
                    modifiedGraph.delete(node);
                });

                const spurPath = dijkstraShortestPath(modifiedGraph, spurNode, endNode);
                if (spurPath) {
                    const totalPath = [...rootPath.slice(0, -1), ...spurPath.path];
                    potentialPaths.enqueue({ path: totalPath, priority: spurPath.cost });
                }
            }
            if (potentialPaths.isEmpty()) {
                break;
            }
            paths.push(potentialPaths.dequeue());
        }
    }

    console.log('Yen\'s K-Shortest Paths:', paths);

    return paths.map(p => p.path);
}


//Comparison of Algorithms and Selection of Optimal Path
function compareAlgorithms(graph, stations) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            const userLat = position.coords.latitude;
            const userLng = position.coords.longitude;

            // Add the user's location as a node in the graph
            graph.set('user', []);
            stations.forEach(station => {
                const distance = Math.sqrt(
                    Math.pow(station.latitude - userLat, 2) + Math.pow(station.longitude - userLng, 2)
                );
                graph.get('user').push({ node: station.name, weight: distance });
                graph.get(station.name).push({ node: 'user', weight: distance });
            });

            const results = [];

            // Bellman-Ford
            const bfStart = performance.now();
            const { distances: bfDistances } = bellmanFord(graph, 'user');
            const bfEnd = performance.now();
            results.push({
                algorithm: 'Bellman-Ford',
                time: bfEnd - bfStart,
                distances: bfDistances,
                timeComplexity: 'O(V * E)',
                spaceComplexity: 'O(V)'
            });

            // Floyd-Warshall
            const fwStart = performance.now();
            const { distances: fwDistances } = floydWarshall(graph);
            const fwEnd = performance.now();
            results.push({
                algorithm: 'Floyd-Warshall',
                time: fwEnd - fwStart,
                distances: fwDistances,
                timeComplexity: 'O(V^3)',
                spaceComplexity: 'O(V^2)'
            });

            // Johnson's
            const jStart = performance.now();
            const jDistances = johnsonsAlgorithm(graph);
            const jEnd = performance.now();
            results.push({
                algorithm: 'Johnson\'s',
                time: jEnd - jStart,
                distances: jDistances,
                timeComplexity: 'O(V^2 * log V + VE)',
                spaceComplexity: 'O(V + E)'
            });

            // Yen's K-Shortest Paths
            const yStart = performance.now();
            const K = 3; // Example value for K
            const yDistances = yenKShortestPaths(graph, 'user', stations.map(s => s.name), K);
            const yEnd = performance.now();
            results.push({
                algorithm: 'Yen\'s K-Shortest Path',
                time: yEnd - yStart,
                distances: yDistances,
                timeComplexity: 'O(K * (V * log V + E))',
                spaceComplexity: 'O(V + E)'
            });

            // Display results and find the optimal algorithm
            displayResults(results);
            const optimalAlgorithm = results.reduce((prev, curr) => prev.time < curr.time ? prev : curr);
            routeUsingOptimalAlgorithm(optimalAlgorithm.algorithm, optimalAlgorithm.distances, userLat, userLng, stations);

        }, (error) => {
            console.error('Error getting user location:', error);
        });
    } else {
        console.error('Geolocation is not supported by this browser.');
    }
}


function displayResults(results) {
    const comparisonDiv = document.getElementById('algorithmComparison');
    comparisonDiv.innerHTML = results.map(result => `
        <p><strong>${result.algorithm}</strong><br>
            Time taken = ${result.time} ms<br>
            Time Complexity = ${result.timeComplexity}<br>
            Space Complexity = ${result.spaceComplexity}
        </p>
    `).join('');

    results.forEach(result => {
        const subBox = document.getElementById(result.algorithm.replace(/[^a-zA-Z]/g, '').toLowerCase());
        if (subBox) {
            subBox.innerHTML = `
                <p><strong>${result.algorithm}</strong><br>
                Time taken = ${result.time.toFixed(2)} ms<br>
                Time Complexity = ${result.timeComplexity}<br>
                Space Complexity = ${result.spaceComplexity}</p>
            `;
        }
    });
}


function routeUsingOptimalAlgorithm(algorithm, distances, userLat, userLng, stations) {
    let nearestStation;
    let minDistance = Infinity;

    switch (algorithm) {
        case 'Bellman-Ford':
            for (const station of stations) {
                if (distances[station.name] < minDistance) {
                    nearestStation = station;
                    minDistance = distances[station.name];
                }
            }
            break;
        case 'Floyd-Warshall':
            for (const station of stations) {
                if (distances['user'][station.name] < minDistance) {
                    nearestStation = station;
                    minDistance = distances['user'][station.name];
                }
            }
            break;
        case 'Johnson\'s':
            for (const station of stations) {
                if (distances['user'][station.name] < minDistance) {
                    nearestStation = station;
                    minDistance = distances['user'][station.name];
                }
            }
            break;
        case 'Yen\'s K-Shortest Path':
            if (distances.length > 0) {
                const shortestPath = distances[0];
                nearestStation = stations.find(s => s.name === shortestPath[shortestPath.length - 1]);
            }
            break;
    }

    if (nearestStation) {
        L.Routing.control({
            waypoints: [
                L.latLng(userLat, userLng),
                L.latLng(nearestStation.latitude, nearestStation.longitude)
            ], 
            createMarker: function(i, wp) {
                return L.marker(wp.latLng, { icon: batteryIcon });
            }
        }).addTo(map);

        // Update infoBox with nearest station details
        updateInfoBox(nearestStation.latitude, nearestStation.longitude, nearestStation.name);
    }
}


// Function to update the infoBox
function updateInfoBox(lat, lng, stationName = '') {
    // Check if infoBox element exists
    const infoBox = document.getElementById('infoBox');
    if (infoBox) {
        infoBox.innerHTML = `
            <p>Nearest Station: ${stationName}<br>
            Latitude: ${lat}<br>
            Longitude: ${lng}</p>
        `;
    }
}

        
